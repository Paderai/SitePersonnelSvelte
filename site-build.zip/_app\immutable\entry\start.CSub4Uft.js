import{l as o,a as r}from"../chunks/GhdDDwm0.js";export{o as load_css,r as start};
